package com.example.gemmaai.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;

public final class ImageUtils {
    private static final int MAX_IMAGE_SIDE = 1024;

    private ImageUtils() {
    }

    public static Bitmap decodeScaledBitmap(Context context, Uri uri) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(input, null, bounds);
        }

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inPreferredConfig = Bitmap.Config.ARGB_8888;
        decode.inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight);
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            Bitmap bitmap = BitmapFactory.decodeStream(input, null, decode);
            if (bitmap == null) {
                throw new IOException("Unable to decode selected image");
            }
            return bitmap;
        }
    }

    private static int calculateSampleSize(int width, int height) {
        int sampleSize = 1;
        while ((width / sampleSize) > MAX_IMAGE_SIDE || (height / sampleSize) > MAX_IMAGE_SIDE) {
            sampleSize *= 2;
        }
        return sampleSize;
    }
}
