package com.example.gemmaai;

import android.content.Context;
import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class LiteRtManager implements AutoCloseable {
    private static final String[] ENGINE_CLASSES = {
            "com.google.ai.edge.litertlm.LlmInference",
            "com.google.ai.edge.litertlm.LiteRtLlm",
            "com.google.ai.edge.litertlm.LiteRtLm",
            "com.google.ai.edge.litertlm.InferenceModel",
            "com.google.ai.edge.litertlm.Llm"
    };

    private static final String[] OPTION_CLASSES = {
            "com.google.ai.edge.litertlm.LlmInference$LlmInferenceOptions",
            "com.google.ai.edge.litertlm.LlmInferenceOptions",
            "com.google.ai.edge.litertlm.LiteRtLlm$Options",
            "com.google.ai.edge.litertlm.LiteRtLlmOptions",
            "com.google.ai.edge.litertlm.LlmOptions"
    };

    private final Context appContext;
    private Object engine;
    private final AtomicBoolean cancelled = new AtomicBoolean(false);

    public LiteRtManager(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public synchronized void load(@NonNull String modelPath) throws Exception {
        close();
        Class<?> engineClass = findFirstClass(ENGINE_CLASSES);
        Object options = createOptions(engineClass, modelPath);
        engine = createEngine(engineClass, options);
    }

    public boolean isLoaded() {
        return engine != null;
    }

    public void generate(String prompt, @Nullable Bitmap image, TokenCallback callback) throws Exception {
        Object currentEngine = engine;
        if (currentEngine == null) {
            throw new IllegalStateException("Load a .litertlm model first");
        }

        cancelled.set(false);
        if (image != null) {
            if (!tryStreamingWithImage(currentEngine, prompt, image, callback)) {
                Object result = invokeBlockingGenerateWithImage(currentEngine, prompt, image);
                if (result != null && !cancelled.get()) {
                    streamText(String.valueOf(result), callback);
                }
            }
            return;
        }

        if (!tryStreaming(currentEngine, prompt, callback)) {
            Object result = invokeBlockingGenerate(currentEngine, prompt);
            if (result != null && !cancelled.get()) {
                streamText(String.valueOf(result), callback);
            }
        }
    }

    public void cancelGeneration() {
        cancelled.set(true);
        invokeNoArg(engine, "cancel");
        invokeNoArg(engine, "cancelGeneration");
        invokeNoArg(engine, "interrupt");
    }

    @Override
    public synchronized void close() {
        cancelled.set(true);
        invokeNoArg(engine, "close");
        invokeNoArg(engine, "dispose");
        engine = null;
    }

    private Object createOptions(Class<?> engineClass, String modelPath) throws Exception {
        Class<?> optionsClass = findOptionsClass(engineClass);
        Method builderMethod = findNoArgStatic(optionsClass, "builder");
        Object builder = builderMethod != null ? builderMethod.invoke(null) : null;
        if (builder != null) {
            invokeSetter(builder, modelPath, "setModelPath", "setModelFilePath", "setModel", "setModelAssetPath");
            invokeIntSetter(builder, 1024, "setMaxTokens", "setMaxOutputTokens", "setMaxResponseTokens");
            Method build = findNoArg(builder.getClass(), "build");
            return build == null ? builder : build.invoke(builder);
        }

        Constructor<?> stringConstructor = findConstructor(optionsClass, String.class);
        if (stringConstructor != null) {
            return stringConstructor.newInstance(modelPath);
        }
        Constructor<?> emptyConstructor = findConstructor(optionsClass);
        if (emptyConstructor != null) {
            Object options = emptyConstructor.newInstance();
            invokeSetter(options, modelPath, "setModelPath", "setModelFilePath", "setModel", "setModelAssetPath");
            return options;
        }
        throw new IllegalStateException("Unable to create LiteRT-LM options from Java");
    }

    private Object createEngine(Class<?> engineClass, Object options) throws Exception {
        for (Method method : engineClass.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())) {
                continue;
            }
            String name = method.getName().toLowerCase(Locale.US);
            Class<?>[] parameters = method.getParameterTypes();
            if ((name.contains("create") || name.contains("load")) && parameters.length == 2
                    && parameters[0].isAssignableFrom(Context.class)
                    && parameters[1].isAssignableFrom(options.getClass())) {
                return method.invoke(null, appContext, options);
            }
            if ((name.contains("create") || name.contains("load")) && parameters.length == 1
                    && parameters[0].isAssignableFrom(options.getClass())) {
                return method.invoke(null, options);
            }
        }

        Constructor<?> contextConstructor = findCompatibleConstructor(engineClass, Context.class, options.getClass());
        if (contextConstructor != null) {
            return contextConstructor.newInstance(appContext, options);
        }
        Constructor<?> optionsConstructor = findCompatibleConstructor(engineClass, options.getClass());
        if (optionsConstructor != null) {
            return optionsConstructor.newInstance(options);
        }
        throw new IllegalStateException("Unable to create LiteRT-LM engine from Java");
    }

    private boolean tryStreaming(Object currentEngine, String prompt, TokenCallback callback) throws Exception {
        for (Method method : currentEngine.getClass().getMethods()) {
            String name = method.getName().toLowerCase(Locale.US);
            Class<?>[] parameters = method.getParameterTypes();
            if (!name.contains("generate") || !name.contains("async") || parameters.length != 2) {
                continue;
            }
            if (!parameters[0].isAssignableFrom(String.class) || !parameters[1].isInterface()) {
                continue;
            }
            CountDownLatch done = new CountDownLatch(1);
            Object listener = Proxy.newProxyInstance(
                    parameters[1].getClassLoader(),
                    new Class<?>[]{parameters[1]},
                    streamingHandler(callback, done)
            );
            method.invoke(currentEngine, prompt, listener);
            done.await(30, TimeUnit.MINUTES);
            return true;
        }
        return false;
    }

    private boolean tryStreamingWithImage(Object currentEngine, String prompt, Bitmap image, TokenCallback callback) throws Exception {
        for (Method method : currentEngine.getClass().getMethods()) {
            String name = method.getName().toLowerCase(Locale.US);
            Class<?>[] parameters = method.getParameterTypes();
            if (!name.contains("generate") || !name.contains("async") || parameters.length != 3) {
                continue;
            }
            if (!parameters[2].isInterface()) {
                continue;
            }
            CountDownLatch done = new CountDownLatch(1);
            Object listener = Proxy.newProxyInstance(
                    parameters[2].getClassLoader(),
                    new Class<?>[]{parameters[2]},
                    streamingHandler(callback, done)
            );
            if (canAcceptTextAndBitmap(parameters[0], parameters[1])) {
                method.invoke(currentEngine, prompt, image, listener);
                done.await(30, TimeUnit.MINUTES);
                return true;
            }
            if (canAcceptBitmapAndText(parameters[0], parameters[1])) {
                method.invoke(currentEngine, image, prompt, listener);
                done.await(30, TimeUnit.MINUTES);
                return true;
            }
        }
        return false;
    }

    private InvocationHandler streamingHandler(TokenCallback callback, CountDownLatch done) {
        return new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) {
                String name = method.getName().toLowerCase(Locale.US);
                if (name.contains("complete") || name.contains("done") || name.contains("finish")) {
                    done.countDown();
                    return null;
                }
                if (name.contains("error") || name.contains("failure")) {
                    done.countDown();
                    return null;
                }
                if (!cancelled.get() && args != null) {
                    for (Object arg : args) {
                        if (arg instanceof CharSequence) {
                            callback.onToken(arg.toString());
                            break;
                        }
                    }
                }
                return null;
            }
        };
    }

    private Object invokeBlockingGenerate(Object currentEngine, String prompt) throws Exception {
        for (Method method : currentEngine.getClass().getMethods()) {
            String name = method.getName().toLowerCase(Locale.US);
            Class<?>[] parameters = method.getParameterTypes();
            if (name.contains("generate") && parameters.length == 1 && parameters[0].isAssignableFrom(String.class)) {
                return method.invoke(currentEngine, prompt);
            }
        }
        throw new IllegalStateException("LiteRT-LM generate method was not found");
    }

    private Object invokeBlockingGenerateWithImage(Object currentEngine, String prompt, Bitmap image) throws Exception {
        for (Method method : currentEngine.getClass().getMethods()) {
            String name = method.getName().toLowerCase(Locale.US);
            Class<?>[] parameters = method.getParameterTypes();
            if (!name.contains("generate") || parameters.length != 2) {
                continue;
            }
            if (canAcceptTextAndBitmap(parameters[0], parameters[1])) {
                return method.invoke(currentEngine, prompt, image);
            }
            if (canAcceptBitmapAndText(parameters[0], parameters[1])) {
                return method.invoke(currentEngine, image, prompt);
            }
        }
        throw new IllegalStateException("This LiteRT-LM model/API does not expose a Java image+prompt generation method");
    }

    private boolean canAcceptTextAndBitmap(Class<?> first, Class<?> second) {
        return first.isAssignableFrom(String.class) && second.isAssignableFrom(Bitmap.class);
    }

    private boolean canAcceptBitmapAndText(Class<?> first, Class<?> second) {
        return first.isAssignableFrom(Bitmap.class) && second.isAssignableFrom(String.class);
    }

    private void streamText(String text, TokenCallback callback) {
        String[] parts = text.split("(?<=\\s)");
        for (String part : parts) {
            if (cancelled.get()) {
                return;
            }
            callback.onToken(part);
        }
    }

    private Class<?> findFirstClass(String[] names) throws ClassNotFoundException {
        for (String name : names) {
            try {
                return Class.forName(name);
            } catch (ClassNotFoundException ignored) {
                // Try the next known Java-facing LiteRT-LM entry point.
            }
        }
        throw new ClassNotFoundException("No known LiteRT-LM Java entry point found");
    }

    private Class<?> findOptionsClass(Class<?> engineClass) throws ClassNotFoundException {
        for (String name : OPTION_CLASSES) {
            try {
                return Class.forName(name);
            } catch (ClassNotFoundException ignored) {
                // Try nested public types exposed by the Java bytecode next.
            }
        }
        for (Class<?> nested : engineClass.getClasses()) {
            String simpleName = nested.getSimpleName().toLowerCase(Locale.US);
            if (simpleName.contains("option") || simpleName.contains("config")) {
                return nested;
            }
        }
        throw new ClassNotFoundException("No LiteRT-LM options class found");
    }

    private Method findNoArgStatic(Class<?> type, String name) {
        for (Method method : type.getMethods()) {
            if (method.getName().equals(name) && method.getParameterTypes().length == 0
                    && Modifier.isStatic(method.getModifiers())) {
                return method;
            }
        }
        return null;
    }

    private Method findNoArg(Class<?> type, String name) {
        for (Method method : type.getMethods()) {
            if (method.getName().equals(name) && method.getParameterTypes().length == 0) {
                return method;
            }
        }
        return null;
    }

    private void invokeSetter(Object target, String value, String... names) throws Exception {
        for (String name : names) {
            for (Method method : target.getClass().getMethods()) {
                if (method.getName().equals(name) && method.getParameterTypes().length == 1
                        && method.getParameterTypes()[0].isAssignableFrom(String.class)) {
                    method.invoke(target, value);
                    return;
                }
            }
        }
    }

    private void invokeIntSetter(Object target, int value, String... names) throws Exception {
        for (String name : names) {
            for (Method method : target.getClass().getMethods()) {
                if (method.getName().equals(name) && method.getParameterTypes().length == 1
                        && method.getParameterTypes()[0] == int.class) {
                    method.invoke(target, value);
                    return;
                }
            }
        }
    }

    private Constructor<?> findConstructor(Class<?> type, Class<?>... parameters) {
        try {
            Constructor<?> constructor = type.getDeclaredConstructor(parameters);
            constructor.setAccessible(true);
            return constructor;
        } catch (NoSuchMethodException ignored) {
            return null;
        }
    }

    private Constructor<?> findCompatibleConstructor(Class<?> type, Class<?>... parameters) {
        for (Constructor<?> constructor : type.getConstructors()) {
            Class<?>[] actual = constructor.getParameterTypes();
            if (actual.length != parameters.length) {
                continue;
            }
            boolean compatible = true;
            for (int i = 0; i < actual.length; i++) {
                if (!actual[i].isAssignableFrom(parameters[i])) {
                    compatible = false;
                    break;
                }
            }
            if (compatible) {
                return constructor;
            }
        }
        return null;
    }

    private void invokeNoArg(Object target, String name) {
        if (target == null) {
            return;
        }
        try {
            Method method = findNoArg(target.getClass(), name);
            if (method != null) {
                method.invoke(target);
            }
        } catch (Exception ignored) {
            // Best-effort cleanup/cancellation.
        }
    }

    public interface TokenCallback {
        void onToken(String token);
    }
}
