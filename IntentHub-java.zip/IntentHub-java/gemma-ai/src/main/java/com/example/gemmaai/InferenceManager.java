package com.example.gemmaai;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;

import com.example.gemmaai.utils.ImageUtils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

public class InferenceManager {
    private final Context appContext;
    private final LiteRtManager liteRtManager;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Future<?> currentTask;
    private final AtomicBoolean generating = new AtomicBoolean(false);

    public InferenceManager(Context context, LiteRtManager liteRtManager) {
        this.appContext = context.getApplicationContext();
        this.liteRtManager = liteRtManager;
    }

    public boolean isGenerating() {
        return generating.get();
    }

    public void generate(String prompt, @Nullable Uri imageUri, Listener listener) {
        cancel();
        StringBuilder response = new StringBuilder();
        generating.set(true);
        postStart(listener);

        currentTask = executor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap image = imageUri == null ? null : ImageUtils.decodeScaledBitmap(appContext, imageUri);
                    liteRtManager.generate(prompt, image, new LiteRtManager.TokenCallback() {
                        @Override
                        public void onToken(String token) {
                            response.append(token);
                            postToken(listener, response.toString());
                        }
                    });
                    postComplete(listener, response.toString());
                } catch (Exception exception) {
                    postError(listener, exception);
                } finally {
                    generating.set(false);
                }
            }
        });
    }

    public void cancel() {
        if (currentTask != null) {
            currentTask.cancel(true);
            currentTask = null;
        }
        liteRtManager.cancelGeneration();
        generating.set(false);
    }

    public void shutdown() {
        cancel();
        executor.shutdownNow();
    }

    private void postStart(Listener listener) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                listener.onStarted();
            }
        });
    }

    private void postToken(Listener listener, String text) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                listener.onToken(text);
            }
        });
    }

    private void postComplete(Listener listener, String text) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                listener.onComplete(text);
            }
        });
    }

    private void postError(Listener listener, Exception exception) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                listener.onError(exception);
            }
        });
    }

    public interface Listener {
        void onStarted();

        void onToken(String text);

        void onComplete(String text);

        void onError(Exception exception);
    }
}
