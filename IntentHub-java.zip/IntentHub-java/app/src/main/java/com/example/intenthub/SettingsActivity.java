package com.example.intenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.intenthub.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    public static final String EXTRA_ACTION = "settings_action";
    public static final String ACTION_CHANGE_MODEL = "change_model";
    public static final String ACTION_CLEAR_CHAT = "clear_chat";

    private ActivitySettingsBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.settingsToolbar.setNavigationOnClickListener(view -> finish());
        binding.changeModelButton.setOnClickListener(view -> finishWithAction(ACTION_CHANGE_MODEL));
        binding.clearChatButton.setOnClickListener(view -> finishWithAction(ACTION_CLEAR_CHAT));
    }

    private void finishWithAction(String action) {
        Intent result = new Intent();
        result.putExtra(EXTRA_ACTION, action);
        setResult(Activity.RESULT_OK, result);
        finish();
    }
}
