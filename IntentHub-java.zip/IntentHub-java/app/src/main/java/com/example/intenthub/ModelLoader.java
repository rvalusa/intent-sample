package com.example.intenthub;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ModelLoader {
    private static final String PREFS = "model_prefs";
    private static final String KEY_MODEL_URI = "model_uri";
    private static final String KEY_MODEL_PATH = "model_path";
    private static final String KEY_MODEL_NAME = "model_name";

    private final Context appContext;

    public ModelLoader(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public ModelInfo persistModel(Uri uri) throws IOException {
        String displayName = queryDisplayName(uri);
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = "selected-model.litertlm";
        }

        File modelDir = new File(appContext.getFilesDir(), "models");
        if (!modelDir.exists() && !modelDir.mkdirs()) {
            throw new IOException("Unable to create model directory");
        }

        File destination = new File(modelDir, sanitize(displayName));
        try (InputStream input = appContext.getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(destination)) {
            if (input == null) {
                throw new IOException("Unable to open selected model");
            }
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
        }

        SharedPreferences prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(KEY_MODEL_URI, uri.toString())
                .putString(KEY_MODEL_PATH, destination.getAbsolutePath())
                .putString(KEY_MODEL_NAME, displayName)
                .apply();

        return new ModelInfo(uri.toString(), destination.getAbsolutePath(), displayName);
    }

    @Nullable
    public ModelInfo getPersistedModel() {
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String path = prefs.getString(KEY_MODEL_PATH, null);
        String uri = prefs.getString(KEY_MODEL_URI, null);
        String name = prefs.getString(KEY_MODEL_NAME, null);
        if (path == null || name == null || !new File(path).exists()) {
            return null;
        }
        return new ModelInfo(uri, path, name);
    }

    private String queryDisplayName(Uri uri) {
        try (Cursor cursor = appContext.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    return cursor.getString(index);
                }
            }
        }
        return uri.getLastPathSegment();
    }

    private String sanitize(String value) {
        return value.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    public static class ModelInfo {
        public final String uri;
        public final String path;
        public final String name;

        public ModelInfo(String uri, String path, String name) {
            this.uri = uri;
            this.path = path;
            this.name = name;
        }
    }
}
