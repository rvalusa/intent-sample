package com.example.intenthub;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.intenthub.databinding.ItemAssistantBinding;
import com.example.intenthub.databinding.ItemUserBinding;
import com.example.intenthub.utils.MarkdownRenderer;

import java.util.ArrayList;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_USER = 1;
    private static final int TYPE_ASSISTANT = 2;

    private final List<Message> messages = new ArrayList<>();

    @Override
    public int getItemViewType(int position) {
        return messages.get(position).getRole() == Message.Role.USER ? TYPE_USER : TYPE_ASSISTANT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_USER) {
            ItemUserBinding binding = ItemUserBinding.inflate(inflater, parent, false);
            return new MessageHolder(binding.getRoot(), binding.messageText, binding.messageImage);
        }
        ItemAssistantBinding binding = ItemAssistantBinding.inflate(inflater, parent, false);
        return new MessageHolder(binding.getRoot(), binding.messageText, null);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messages.get(position);
        MessageHolder messageHolder = (MessageHolder) holder;
        messageHolder.messageText.setText(MarkdownRenderer.render(message.getText()));
        if (messageHolder.messageImage != null) {
            if (message.hasImage()) {
                messageHolder.messageImage.setVisibility(View.VISIBLE);
                messageHolder.messageImage.setImageURI(Uri.parse(message.getImageUri()));
            } else {
                messageHolder.messageImage.setVisibility(View.GONE);
                messageHolder.messageImage.setImageDrawable(null);
            }
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public void add(Message message) {
        messages.add(message);
        notifyItemInserted(messages.size() - 1);
    }

    public void updateLastAssistant(String text, boolean streaming) {
        for (int i = messages.size() - 1; i >= 0; i--) {
            Message message = messages.get(i);
            if (message.getRole() == Message.Role.ASSISTANT) {
                message.setText(text);
                message.setStreaming(streaming);
                notifyItemChanged(i);
                return;
            }
        }
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void clear() {
        messages.clear();
        notifyDataSetChanged();
    }

    static class MessageHolder extends RecyclerView.ViewHolder {
        final TextView messageText;
        final ImageView messageImage;

        MessageHolder(@NonNull View itemView, @NonNull TextView messageText, ImageView messageImage) {
            super(itemView);
            this.messageText = messageText;
            this.messageImage = messageImage;
        }
    }
}
