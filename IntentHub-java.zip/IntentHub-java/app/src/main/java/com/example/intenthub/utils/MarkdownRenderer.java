package com.example.intenthub.utils;

import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MarkdownRenderer {
    private static final Pattern BOLD = Pattern.compile("\\*\\*(.+?)\\*\\*");
    private static final Pattern INLINE_CODE = Pattern.compile("`([^`]+)`");

    private MarkdownRenderer() {
    }

    public static CharSequence render(String source) {
        String safe = source == null ? "" : source;
        SpannableStringBuilder builder = new SpannableStringBuilder(
                safe.replace("### ", "").replace("## ", "").replace("# ", "")
        );
        applySpan(builder, BOLD, 2, new SpanFactory() {
            @Override
            public Object create() {
                return new StyleSpan(Typeface.BOLD);
            }
        });
        applySpan(builder, INLINE_CODE, 1, new SpanFactory() {
            @Override
            public Object create() {
                return new TypefaceSpan("monospace");
            }
        });
        return builder;
    }

    private static void applySpan(SpannableStringBuilder builder, Pattern pattern, int markerChars, SpanFactory factory) {
        Matcher matcher = pattern.matcher(builder.toString());
        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            builder.delete(end - markerChars, end);
            builder.delete(start, start + markerChars);
            int contentEnd = end - markerChars * 2;
            builder.setSpan(factory.create(), start, contentEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            matcher = pattern.matcher(builder.toString());
        }
    }

    private interface SpanFactory {
        Object create();
    }
}
