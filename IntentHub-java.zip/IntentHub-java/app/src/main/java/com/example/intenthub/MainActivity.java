package com.example.intenthub;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.gemmaai.InferenceManager;
import com.example.gemmaai.LiteRtManager;
import com.example.intenthub.databinding.ActivityMainBinding;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private ChatAdapter adapter;
    private ModelLoader modelLoader;
    private LiteRtManager liteRtManager;
    private InferenceManager inferenceManager;
    private ExecutorService modelExecutor;
    private boolean modelLoading;
    private boolean modelPromptShowing;
    @Nullable
    private Uri selectedImageUri;

    private final ActivityResultLauncher<String[]> modelPicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onModelPicked);

    private final ActivityResultLauncher<String[]> imagePicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onImagePicked);

    private final ActivityResultLauncher<Intent> settingsLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
                    return;
                }
                String action = result.getData().getStringExtra(SettingsActivity.EXTRA_ACTION);
                if (SettingsActivity.ACTION_CHANGE_MODEL.equals(action)) {
                    openModelPicker();
                } else if (SettingsActivity.ACTION_CLEAR_CHAT.equals(action)) {
                    adapter.clear();
                }
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        modelLoader = new ModelLoader(this);
        liteRtManager = new LiteRtManager(this);
        inferenceManager = new InferenceManager(this, liteRtManager);
        modelExecutor = Executors.newSingleThreadExecutor();

        setupRecyclerView();
        setupToolbar();
        setupInput();
        restoreModel();
    }

    private void setupRecyclerView() {
        adapter = new ChatAdapter();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        binding.messages.setLayoutManager(layoutManager);
        binding.messages.setAdapter(adapter);
    }

    private void setupToolbar() {
        binding.toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_model) {
                openModelPicker();
                return true;
            }
            if (item.getItemId() == R.id.action_settings) {
                settingsLauncher.launch(new Intent(this, SettingsActivity.class));
                return true;
            }
            return false;
        });
    }

    private void setupInput() {
        binding.sendButton.setOnClickListener(view -> sendPrompt());
        binding.stopButton.setOnClickListener(view -> stopGeneration());
        binding.attachImageButton.setOnClickListener(view -> {
            if (ensureModelAvailable()) {
                openImagePicker();
            }
        });
        binding.removeImageButton.setOnClickListener(view -> clearSelectedImage());
        binding.promptInput.setOnClickListener(view -> ensureModelAvailable());
        binding.promptInput.setOnFocusChangeListener((view, hasFocus) -> {
            if (hasFocus) {
                ensureModelAvailable();
            }
        });
        binding.promptInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence text, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence text, int start, int before, int count) {
                if (text.length() > 0) {
                    ensureModelAvailable();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        binding.promptInput.setOnEditorActionListener((textView, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendPrompt();
                return true;
            }
            return false;
        });
        setGenerating(false);
        binding.sendButton.setEnabled(false);
    }

    private void restoreModel() {
        ModelLoader.ModelInfo modelInfo = modelLoader.getPersistedModel();
        if (modelInfo == null) {
            setModelStatus(getString(R.string.model_missing));
            return;
        }
        loadModel(modelInfo);
    }

    private void openModelPicker() {
        modelPicker.launch(new String[]{"application/octet-stream", "*/*"});
    }

    private void openImagePicker() {
        imagePicker.launch(new String[]{"image/*"});
    }

    private void onImagePicked(Uri uri) {
        if (uri == null) {
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // The picker grant remains valid for the active chat session.
        }
        selectedImageUri = uri;
        binding.imagePreview.setImageURI(uri);
        binding.imagePreviewContainer.setVisibility(View.VISIBLE);
    }

    private void clearSelectedImage() {
        selectedImageUri = null;
        binding.imagePreview.setImageDrawable(null);
        binding.imagePreviewContainer.setVisibility(View.GONE);
    }

    private void onModelPicked(Uri uri) {
        if (uri == null) {
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // The copied internal model file is enough if the provider does not grant persistence.
        }
        setLoading(true, getString(R.string.loading_model));
        modelExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    ModelLoader.ModelInfo modelInfo = modelLoader.persistModel(uri);
                    runOnUiThread(() -> loadModel(modelInfo));
                } catch (Exception exception) {
                    runOnUiThread(() -> showError("Could not copy model: " + exception.getMessage()));
                }
            }
        });
    }

    private void loadModel(ModelLoader.ModelInfo modelInfo) {
        setLoading(true, getString(R.string.loading_model));
        modelExecutor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    liteRtManager.load(modelInfo.path);
                    runOnUiThread(() -> {
                        setLoading(false, getString(R.string.model_ready) + ": " + modelInfo.name);
                        binding.sendButton.setEnabled(true);
                    });
                } catch (Exception exception) {
                    runOnUiThread(() -> showError("Could not load LiteRT-LM model: " + exception.getMessage()));
                }
            }
        });
    }

    private void sendPrompt() {
        String prompt = binding.promptInput.getText().toString().trim();
        Uri imageUri = selectedImageUri;
        if (prompt.isEmpty() && imageUri == null) {
            return;
        }
        if (!ensureModelAvailable()) {
            return;
        }
        if (inferenceManager.isGenerating()) {
            return;
        }

        String userPrompt = prompt.isEmpty() ? "Describe this image." : prompt;
        binding.promptInput.setText("");
        clearSelectedImage();

        Message userMessage = new Message(Message.Role.USER, userPrompt);
        if (imageUri != null) {
            userMessage.setImageUri(imageUri.toString());
        }
        adapter.add(userMessage);
        Message assistant = new Message(Message.Role.ASSISTANT, "");
        assistant.setStreaming(true);
        adapter.add(assistant);
        scrollToBottom();

        inferenceManager.generate(buildPrompt(), imageUri, new InferenceManager.Listener() {
            @Override
            public void onStarted() {
                setGenerating(true);
            }

            @Override
            public void onToken(String text) {
                adapter.updateLastAssistant(text, true);
                scrollToBottom();
            }

            @Override
            public void onComplete(String text) {
                adapter.updateLastAssistant(text, false);
                setGenerating(false);
                scrollToBottom();
            }

            @Override
            public void onError(Exception exception) {
                adapter.updateLastAssistant("Error: " + exception.getMessage(), false);
                setGenerating(false);
                scrollToBottom();
            }
        });
    }

    private String buildPrompt() {
        StringBuilder prompt = new StringBuilder();
        for (Message message : adapter.getMessages()) {
            if (message.getRole() == Message.Role.USER) {
                prompt.append("User: ");
            } else {
                if (message.isStreaming()) {
                    continue;
                }
                prompt.append("Assistant: ");
            }
            if (message.hasImage()) {
                prompt.append("[Image attached] ");
            }
            prompt.append(message.getText()).append('\n');
        }
        prompt.append("Assistant: ");
        return prompt.toString();
    }

    private void stopGeneration() {
        inferenceManager.cancel();
        adapter.updateLastAssistant("Generation stopped.", false);
        setGenerating(false);
    }

    private void setGenerating(boolean generating) {
        binding.sendButton.setVisibility(generating ? View.GONE : View.VISIBLE);
        binding.stopButton.setVisibility(generating ? View.VISIBLE : View.GONE);
        binding.loadingIndicator.setVisibility(generating ? View.VISIBLE : View.GONE);
        binding.promptInput.setEnabled(!generating);
        binding.attachImageButton.setEnabled(!generating);
        binding.removeImageButton.setEnabled(!generating);
    }

    private void setLoading(boolean loading, String status) {
        modelLoading = loading;
        binding.loadingIndicator.setVisibility(loading ? View.VISIBLE : View.GONE);
        setModelStatus(status);
        binding.sendButton.setEnabled(!loading);
        binding.attachImageButton.setEnabled(!loading);
    }

    private void showError(String message) {
        setLoading(false, message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void setModelStatus(String status) {
        binding.modelStatus.setText(status);
    }

    private boolean ensureModelAvailable() {
        if (liteRtManager.isLoaded()) {
            return true;
        }
        if (modelLoading) {
            Toast.makeText(this, R.string.loading_model, Toast.LENGTH_SHORT).show();
            return false;
        }
        setModelStatus(getString(R.string.model_missing));
        showModelRequiredPrompt();
        return false;
    }

    private void showModelRequiredPrompt() {
        if (modelPromptShowing) {
            return;
        }
        modelPromptShowing = true;
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.model_required_title)
                .setMessage(R.string.model_required_message)
                .setPositiveButton(R.string.choose_model, (dialog, which) -> openModelPicker())
                .setNegativeButton(android.R.string.cancel, null)
                .setOnDismissListener(dialog -> modelPromptShowing = false)
                .show();
    }

    private void scrollToBottom() {
        if (adapter.getItemCount() > 0) {
            binding.messages.post(() -> binding.messages.smoothScrollToPosition(adapter.getItemCount() - 1));
        }
    }

    @Override
    protected void onDestroy() {
        inferenceManager.shutdown();
        liteRtManager.close();
        modelExecutor.shutdownNow();
        super.onDestroy();
    }
}
