package com.example.intenthub;

import androidx.annotation.Nullable;

public class Message {
    public enum Role {
        USER,
        ASSISTANT
    }

    private final Role role;
    private String text;
    @Nullable
    private String imageUri;
    private boolean streaming;

    public Message(Role role, String text) {
        this.role = role;
        this.text = text;
    }

    public Role getRole() {
        return role;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text == null ? "" : text;
    }

    @Nullable
    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(@Nullable String imageUri) {
        this.imageUri = imageUri;
    }

    public boolean hasImage() {
        return imageUri != null && !imageUri.trim().isEmpty();
    }

    public boolean isStreaming() {
        return streaming;
    }

    public void setStreaming(boolean streaming) {
        this.streaming = streaming;
    }
}
